This project helps solving the incompatibilty of Behave's genereated json reports to tools using Cucumber json reports. Its done by reformatting the Behave json to Cucumber json.


